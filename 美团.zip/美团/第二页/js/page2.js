/**********************************nav��ʼ*/
/*****************************************************option��ʼ*/
/*1.�����˵�ѡ�*/
window.addEventListener('load',function(){
    var options=document.getElementById('options');
    var optionsdivs=options.getElementsByTagName('div');
    var optionslis=options.getElementsByTagName('li');
    var movebox=document.getElementById('movebox');

    for(var i=0;i<optionslis.length;i++)
    {
        optionslis[i].index=i;

        optionslis[i].onmouseover=function()
        {
            for(var j=0;j<optionsdivs.length;j++)
            {
                optionsdivs[j].style.display='none';
            }
            optionsdivs[this.index].style.display='block'
        };

        optionslis[i].onmouseout=function()
        {
            optionsdivs[this.index].style.display='none';
        }
    }
});
/*********************************************************option����*/
/***********************************************************nav��ʼ*/
/*1.�����˵�*/
window.addEventListener('load',function(){
    var downlist2=document.getElementById('downlist');
    var all=document.getElementById('all');
    var arrow1=document.getElementById('arrow1');

    all.onmouseover=function()
    {
        downlist2.style.display='block';
        arrow1.style.background='url("images/up.png") no-repeat';  /*��Ϊ���js�Ƿ���html�ļ������õģ�����images�ļ��к�HTML�ļ���ͬһλ��*/
        /* arrow1.style.background='red';*/
    };

    all.onmouseout=function()
    {
        downlist2.style.display='none';
        arrow1.style.background='url("images/down.png") no-repeat';
    };
});
/**********************************nav����*/

/************************************************banner��ʼ*/
/*1.�رչ�沿��*/
var banner=document.getElementById('banner');
var chahao=document.getElementById('chahao');

chahao.onclick=function() {
    banner.style.display = 'none';
};
/***************************************************banner����*/

/******************************************************links*/
/*1.ѡ�*/
var links=document.getElementById('links');
var lis=links.getElementsByTagName('li');
var divs=links.getElementsByTagName('div');
for(var i=0;i<lis.length;i++)
{
    lis[i].index=i;
    lis[i].onmouseover=function()
    {

        for(var i=0;i<divs.length;i++)
        {
            divs[i].style.display='none';
        }
        divs[this.index].style.display='block';
    };

}
/*******************************************************links����*/




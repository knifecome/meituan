/**
 * Created by 17K on 2016/9/22.
 */
/*ȡ��ͬ�ຯ��*/
/*function getByClass(oParent,sClass)
{
    var aEle=oParent.getElementsByTagName('*');
    var aResults=[];

    for(var i=0;i<aEle.length;i++)
    {
        if(aEle[i].className==sClass)
        {
            aResults.push(aEle[i]);
        }
    }

    return aResults;
}*/
/*******************************************************�㼶����.top���ֿ�ʼ*/
/*�ֻ����������򲿷������Ƴ�*/
var mobie_a=document.getElementById('mobile_a');
var mobieli=document.getElementById('mobileli');
var freebox=document.getElementById('freebox');

mobieli.onmouseover=function()
{
    freebox.className='toggle on';
    mobie_a.className='showborder';
};

mobieli.onmouseout=function()
{
    freebox.className='toggle';
    mobie_a.className='';
};

/*�ҵ����������򲿷������Ƴ�*/
var mya=document.getElementById('mya');
var myli=document.getElementById('myli');
var mybox=document.getElementById('mybox');

myli.onmouseover=function()
{
    mybox.className='toggle on right';
    mya.className='showborder';
};

myli.onmouseout=function()
{
    mybox.className='toggle';
    mya.className='';
};

/*��ϵ�ͷ������򲿷������Ƴ�*/
var connecta=document.getElementById('connecta');
var connectli=document.getElementById('connectli');
var connectbox=document.getElementById('connectbox');

connectli.onmouseover=function()
{
    connectbox.className='toggle on right';
    connecta.className='showborder';
};

connectli.onmouseout=function()
{
    connectbox.className='toggle';
    connecta.className='';
};

/*�̼������򲿷������Ƴ�*/
var businessa=document.getElementById('businessa');
var businessli=document.getElementById('businessli');
var businessbox=document.getElementById('businessbox');

businessli.onmouseover=function()
{
    businessbox.className='toggle on right';
    businessa.className='showborder';
};

businessli.onmouseout=function()
{
    businessbox.className='toggle';
    businessa.className='';
};

/*���������򲿷������Ƴ�*/
var morea=document.getElementById('morea');
var moreli=document.getElementById('moreli');
var morebox=document.getElementById('morebox');

moreli.onmouseover=function()
{
    morebox.className='toggle on right';
    morea.className='showborder';
};

moreli.onmouseout=function()
{
    morebox.className='toggle';
    morea.className='';
};
/*******************************************************�㼶����.top���ֽ���*/

/***********************************************************3.nav���ֿ�ʼ*/
/*��һ��*/
/*var li1=document.getElementById('li1');
var sublist1=document.getElementById('sublist1');
var right_toggle1=document.getElementById('right_toggle1');
var arrow=document.getElementById('arrow');

li1.onmouseover=function()
{
    li1.className='white';
    sublist1.className='sublist r-border';
    right_toggle1.className='right-toggle on2';
    arrow.className='arrow arrowlost';
}

li1.onmouseout=function()
{
    li1.className='';
    sublist1.className='sublist';
    right_toggle1.className='right-toggle'
    arrow.className='arrow';
}*/

/*�����м򻯷���1*/
/*var downlist=document.getElementById('downlist');
var downul=document.getElementById('downul');
var lis=downlist.getElementsByTagName('li');


var sublist=getByClass(downul,'sublist');
//alert(sublist.length);   //���һ����Ϊsublist last ��������һ����������HTML������һ�����õ�����Ϊsublist��div

var arrow=getByClass(downul,'arrow');

var right_toggle=getByClass(downul,'right_toggle');
//alert(right_toggle.length);   //0����Ϊright_toggleΪdisplay��none״̬



for(var i=0;i<lis.length;i++)
{
    lis[i].index=i;
    lis[i].onmouseover=function()
    {
        this.className='white';
        sublist[this.index].className='sublist r-border';
        arrow[this.index].className='arrow arrowlost';
    }
}*/

/*����2*/
/*�����˵�*/
var downlist=document.getElementById('downlist');
var lis=downlist.getElementsByTagName('li');
for(var i=0;i<lis.length;i++)
{
    lis[i].onmouseover=function()
    {
        this.className='on2';
    }

    lis[i].onmouseout=function()
    {
        this.className='';
    }
}

/*�ֲ�ͼ��ʼ*/
var navwrapbox=document.getElementById('navwrapbox');
var navm_unit=document.getElementById('navm_unit');
var navul=navwrapbox.getElementsByTagName('ul')[0];
var navlis=navul.getElementsByTagName('li');

navul.innerHTML+=navul.innerHTML;

var count=0;
var navtimer=null;
function move2()
{
    count++;
    navm_unit.style.left=-688*count+'px';
    clearInterval(navtimer);
    setTimeout(move2,5000);
    if(count>1)
    {
        count=0;
    }
}

navtimer=setInterval(move2,2000);
/*nav�ֲ�ͼ����*/
/***********************************************************3.nav���ֽ���*/
/*4.famous���ֿ�ʼ*/
/*����ʱЧ��*/
var famousclock=document.getElementById('famousclock');
var spans=famousclock.getElementsByTagName('span');
var number=24*60*60;    //24Сʱ������
var targettime=0;
var timer=setInterval(countdown,1000);
countdown();

function countdown(){
    number--;
    if(number<0)
    {
        clearInterval(timer);
        return;
    }
    var hour=parseInt(number/60/60);   //ʱ
    var minute=parseInt(number/60)%60; //��
    var second=number%60;              //��

    spans[0].innerHTML=parseInt(hour/10);
    spans[1].innerHTML=hour%10;
    spans[2].innerHTML=parseInt(minute/10);
    spans[3].innerHTML=minute%10;
    spans[4].innerHTML=parseInt(second/10);
    spans[5].innerHTML=second%10;
}
/*����ʱЧ��*/
/*�ֲ�ͼ*/
window.addEventListener('load',function(){
    var m_unit=document.getElementById('m_unit');
    var ul=m_unit.getElementsByTagName('ul')[0];
    var lis=ul.getElementsByTagName('li');


    var width=1175;     //ÿ��С���Ŀ���
//var len=lis.length;   //����ul���������ǰ�ĳ���,���������5�����

    ul.innerHTML+=ul.innerHTML;

    var idx=0;
    function move(){
        idx++;
        animate(m_unit,{'left':-idx*width},4000,function(){
            if(idx>0)    /*��Ϊֻ������0��1*/
            {
                idx=0;
                m_unit.style.left='0px';
            }
        })
    }
    setInterval(move,8000);
});

/*�ֲ�ͼ*/
/*4.famous���ֽ���*/
/**********************************************************13.linksѡ���ʼ*/
var links=document.getElementById('links');
var lis=links.getElementsByTagName('li');
var divs=links.getElementsByTagName('div');
for(var i=0;i<lis.length;i++)
{
    lis[i].index=i;
    lis[i].onmouseover=function()
    {
        for(var i=0;i<divs.length;i++)
        {
            divs[i].style.display='none';
        }
        divs[this.index].style.display='block';
    };

}
/**********************************************************13.linksѡ�����*/


